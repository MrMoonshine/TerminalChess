class Bkg
{
	String black = "\u001B[40m";
	String red = "\u001B[41m";
	String blue = "\u001B[44m";
	String green = "\u001B[42m";
	String yellow = "\u001B[43m";
	String pink = "\u001B[45m";
	String cyan = "\u001B[46m";
	String white = "\u001B[47m";
}