class Col
    {
        String res = "\u001B[0m";
        String red = "\u001B[31m";
        String blue = "\u001B[34m";
        String green = "\u001B[32m";
        String yellow = "\u001B[33m";
        String pink = "\u001B[35m";
        String cyan = "\u001B[36m";
    }