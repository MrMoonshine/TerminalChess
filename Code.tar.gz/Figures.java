class Figures
{
    int player;
    String fig;
    boolean possible;
}