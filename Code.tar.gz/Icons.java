class Icons
{
    String king = "\u2654";
    String queen = "\u2655";
    String tower = "\u2656";
    String pope = "\u2657";
    String horse = "\u2658";
    String farmer = "\u2659";
}